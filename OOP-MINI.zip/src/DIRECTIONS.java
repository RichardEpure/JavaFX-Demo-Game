public enum DIRECTIONS
{
    NORTH,
    EAST,
    SOUTH,
    WEST,
    UNDEFINED;
}
