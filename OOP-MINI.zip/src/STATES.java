public enum STATES
{
    IDLE,
    MOVING,
    ATTACK;
}
